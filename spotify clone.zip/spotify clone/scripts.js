// Add your JavaScript here if needed
document.addEventListener('DOMContentLoaded', function () {
    // Example: Adding a click event to play/pause buttons
    document.querySelector('.btn-outline-light').addEventListener('click', function () {
        alert('Button clicked!');
    });
});
